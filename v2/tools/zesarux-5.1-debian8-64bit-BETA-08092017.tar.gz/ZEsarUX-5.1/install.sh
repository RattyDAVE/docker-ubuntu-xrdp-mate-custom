#!/bin/bash

echo "Installing ZEsarUX under /usr ..."

mkdir -p /usr
mkdir -p /usr/bin
mkdir -p /usr/share/zesarux/

cp zesarux /usr/bin/
cp *.rom zxuno.flash tbblue.mmc /usr/share/zesarux/

cp mantransfev3.bin /usr/share/zesarux/

cp -r speech_filters /usr/share/zesarux/
cp -r my_soft /usr/share/zesarux/

cp ACKNOWLEDGEMENTS Changelog HISTORY LICENSE LICENSE_MOTOROLA_CORE LICENSE_SCMP_CORE README FEATURES INSTALL INSTALLWINDOWS ALTERNATEROMS INCLUDEDTAPES DONATE FAQ /usr/share/zesarux/
find /usr/share/zesarux/ -type f -print0| xargs -0 chmod 444

#chmod +x /usr/share/zesarux/macos_say_filter.sh
chmod +x /usr/share/zesarux/speech_filters/*

echo "Install done"

